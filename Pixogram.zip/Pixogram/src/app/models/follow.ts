export class Follow{
    public id:number;
    
    constructor(
            public userId:number,
            public followId:number
    ){}
}